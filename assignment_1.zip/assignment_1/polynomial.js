//Daniel Rogers - #528292 - COP2801
var x = 2.55; //define value of x
var result=(3*x**3-5*x**2+6); //define result when x is substituted into the given polynomial
console.log(result); //print the result to the console
